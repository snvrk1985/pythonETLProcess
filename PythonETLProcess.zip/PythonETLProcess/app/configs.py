url=""
requestfrom=""
#here we are configuring url to connect fastapi based on database.
def urlConfig(apiurl):
    if apiurl=="source":
        url="http://127.0.0.1:8002"
    elif apiurl=="target":
        url="http://127.0.0.1:8003"
    return url
def DatabaseName(dbname):
   global database
   database=dbname
def get_database_name():
    return database

