from sqlalchemy import create_engine,text
from sqlalchemy.orm import sessionmaker
import base_model,configs
# Function to dynamically create engine based on database name

dbname = configs.get_database_name()
DATABASE_URL = ""
if dbname == "source":
    DATABASE_URL = "sqlite:///./source.db"  # SQLite URL for source database
elif dbname == "target":
    DATABASE_URL = "sqlite:///./target.db" 
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False,"timeout": 10}) # connecting to sqlite3 database
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine) # creating session 
base_model.Base.metadata.create_all(engine)
# FastAPI dependency to provide a database session
def get_db():
    db=SessionLocal()
    try:
        yield db
    finally:
        db.close()

#below is the function to check database connected successfully or not
def test_connection():
    with engine.connect() as connection:
        result = connection.execute(text("SELECT 1"))
        print(result.scalar())  # Should print '1' if successful
#test_connection()

