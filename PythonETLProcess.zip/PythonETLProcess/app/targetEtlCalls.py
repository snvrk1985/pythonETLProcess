from datetime import datetime
from io import StringIO
from threading import Lock
from fastapi import HTTPException
import pandas as pd
import requests,configs,os,sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))) 
from cloud.accessS3 import copyToS3 
db_lock = Lock()

#migratedstudentDetails = []
studDetails=[]


def execute_migration(ready_to_migrate,stdDetails,url):
    if ready_to_migrate:
        global migratedstudentDetails
        migrateStudents(url,stdDetails)


def fetchmigratedSutdents(url,stdDetails):
    migratedstudentDetails = []  # Initialize to avoid "variable not defined" issues
    try:
        response = requests.get(f"{url}/fetch_migrated_students/")
        #print(f"Response in fetch migrate students: {response}")
        if response and response.status_code == 200:  # Check for successful response
            migratedstudentDetails = response.json()  # Parse response
        else:
            print("Failed to fetch students or no valid response returned")
    except Exception as e:
        print(f"Error in calling API: {e}")
    finally:
        print(f"Students in target table: {migratedstudentDetails}")
        #students_records_to_migrate(url, stdDetails, migratedstudentDetails)
        #migrateStudents(url,stdDetails)
            
    


#function to migrate students
def migrateStudents(url,studentDetails):
      # Initialize list to collect student IDs
    migratedstudentDetails=[]
    for data in studentDetails:
        try:
            # Send POST request to insert each student
            response = requests.post(f"{url}/insert_migrate_students/", json=data)
            #print(f"Response for Student ID {response.status_code}, {response.text}")
            # If insertion is successful
            if response.status_code in [200, 201]:
                migratedstudentDetails.append(response.json())
                updateEtlStatus(migratedstudentDetails)
                #updateEtlStatus(response.json())
                '''records = response.json()
                for record in records:
                    migratedstudentDetails.append(record) 
                    updateEtlStatus(migratedstudentDetails)'''
            else:
                print(f"Failed to migrate student record: {data}. Status: {response.status_code}")
                return []
        except Exception as e:
            # Log error and raise HTTPException for API failure
            print(f"Error in calling API: {e}")
            raise HTTPException(status_code=500, detail=f"Error calling API: {str(e)}")
        
    
#function to return student Id's to source file, to update the flag etlExecuted from 0 to 1. 
# So that from next time onwards these student id's should not come for Process.
def updateEtlStatus(migratedStudents):
    print(f"Migrated students are {migratedStudents}")
    stdIds=[]
    if isinstance(migratedStudents, dict):  # Single record case
        stdIds = [migratedStudents["id"]]
    elif isinstance(migratedStudents, list):  # List case
        stdIds = [stdId["id"] for stdId in migratedStudents]
    else:
        stdIds=[]
    if stdIds:
        if isinstance(stdIds, list):
                stdIds = ",".join(map(str, stdIds))
                print(f"student id's in update status function with comma seperated {stdIds}")
        try:
            url=configs.urlConfig("source")
            configs.DatabaseName("source")
            response = requests.put(f"{url}/student/{stdIds}/")
            if response.status_code == 200:
                if isinstance(migratedStudents, dict):
                    migratedStudents = [migratedStudents] 
                df=pd.DataFrame(migratedStudents)
                df.to_csv("files/students.csv",index=False)
                migrated=copyToS3("files/students.csv")
                if migrated:
                    file_path = "files/students.csv"  # Replace with your actual file path
                    # Check if the file exists before deleting
                    if os.path.exists(file_path):
                        os.remove(file_path)
                        print(f"{file_path} has been deleted.")
        except Exception as e:
            print(f"error in calling API is {e}")
            raise HTTPException(status_code=500,detail=(str(e)))
        

  