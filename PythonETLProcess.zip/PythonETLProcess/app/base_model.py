from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import Identity,Column,Integer,String,DateTime,Boolean
import configs
dbname = configs.get_database_name()




class Base(DeclarativeBase):
    pass

class StudentTable(Base):
    __tablename__="student_table"
    id_identity=Identity(start=1,increment=1)
    id=Column(Integer,id_identity,primary_key=True)
    fname=Column(String(50),nullable=False)
    lname=Column(String(50),nullable=False)
    contact=Column(Integer,nullable=True)
    age=Column(Integer,nullable=True)
    if dbname=="source":
        etlExecuted=Column(Boolean,nullable=False,default=False)
    insertDate=Column(DateTime,nullable=True)

'''class StudentFee(Base):
    __tablename__="student_feee"
    id = Column(Integer, primary_key=True, autoincrement=True)
    stdid=Column(Integer, ForeignKey("student_table.id"), nullable=False)
    fee=Column(Integer,nullable=False)

class StudentClass(Base):
    __tablename__="student_class"
    id = Column(Integer, primary_key=True, autoincrement=True)
    stdid=Column(Integer, ForeignKey("student_table.id"), nullable=False)
    stdClass=Column(Integer,nullable=False)'''
