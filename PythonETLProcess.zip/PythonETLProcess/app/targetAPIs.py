from datetime import datetime
from urllib.parse import urlparse
from fastapi import FastAPI, HTTPException, Depends
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from typing import Annotated
import configs # Assuming models are defined correctly in `models.py`
app = FastAPI()

url=configs.urlConfig("target")
configs.DatabaseName("target")
import database,base_model
from pydantic_models import StudentResponse

#api Call to insert records from source table which are not available in the table
@app.post("/insert_migrate_students/", response_model=StudentResponse)
def insert_migrate_students(student: StudentResponse, db: Session = Depends(database.get_db)):
    try:
        existing_student = db.query(base_model.StudentTable).filter(base_model.StudentTable.id == student.id).first()

        if existing_student:
            try:
                existing_student.fname = student.fname
                existing_student.lname = student.lname
                existing_student.age = student.age
                existing_student.contact = student.contact
                existing_student.insertDate = datetime.now()
                db.commit()
                db.refresh(existing_student)
                existing_student_dict = {column.name: getattr(existing_student, column.name) for column in base_model.StudentTable.__table__.columns}
                validated_student = StudentResponse.model_validate(existing_student_dict)  # ✅ Convert ORM object to Pydantic model
                return JSONResponse(content=jsonable_encoder(validated_student.model_dump()), status_code=200)
                
            except Exception as e:
                db.rollback()
                raise HTTPException(status_code=500, detail=f"An error occurred while updating: {str(e)}")

        else:
            try:
                new_student = base_model.StudentTable(
                    id=student.id,
                    fname=student.fname,
                    lname=student.lname,
                    age=student.age,
                    contact=student.contact,
                    insertDate=datetime.now()
                )
                db.add(new_student)
                db.commit()
                db.refresh(new_student)
                new_student_dict = {column.name: getattr(new_student, column.name) for column in base_model.StudentTable.__table__.columns}
                validated_student = StudentResponse.model_validate(new_student_dict)  # ✅ Convert ORM object to Pydantic model
                return JSONResponse(content=jsonable_encoder(validated_student.model_dump()), status_code=201)  # ✅ Returns new student
                
            except Exception as e:
                db.rollback()
                raise HTTPException(status_code=500, detail=f"An error occurred while inserting: {str(e)}")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")    
    

#api call to fetch migrated student details.
@app.get("/fetch_migrated_students/")
def fetch_migrated_students(db: Annotated[Session, Depends(database.get_db)]):
    try:
        all_students = db.query(base_model.StudentTable).all()
    except Exception as e:
       print(f"error during api call is {e}")
       raise HTTPException(status_code=500, detail=f"An error occurred while fetching students: {str(e)}")
    if not all_students:
        raise HTTPException(status_code=404, detail="No student records found")
    return [student.__dict__ for student in all_students]  # Ensuring correct serialization


if __name__=='__main__':
    import uvicorn
     #fetching host and port nme based on the url, which is coming from the configs.
    #Url will change based on the data base and based on the environment.
    parsed_url = urlparse(url)
    host = parsed_url.hostname  # Get the host (e.g., '127.0.0.1')
    port = parsed_url.port 
    uvicorn.run(app,host=host,port=port)
    #uvicorn.run(app,host='127.0.0.1',port=8003)