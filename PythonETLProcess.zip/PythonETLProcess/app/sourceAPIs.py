from urllib.parse import urlparse
from fastapi import FastAPI, HTTPException, Depends, status
from sqlalchemy.orm import Session
from typing import Annotated, List, Union
import configs  # Assuming models are defined correctly in `models.py`
from datetime import datetime
import time

app = FastAPI()
timestamp = datetime.now().isoformat()
stdDetails=[]

#database.DatabaseName("source")
url=configs.urlConfig("source")
configs.DatabaseName("source")
import database,pydantic_models,base_model
@app.post("/students/")
def create_student_details(
    db: Annotated[Session, Depends(database.get_db)],  # Correct use of Depends
    student_details: pydantic_models.StudentTable # Pydantic model for student details
):
    # Convert Pydantic model into SQLAlchemy model
    new_student = base_model.StudentTable(**student_details.model_dump())

    try:
        # Add the student record to the database
        db.add(new_student)
        db.commit()
    except Exception as e:
        print(f"Error occurred: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not add student details."
        )

    # Return success response
    return {
        "result": "Student details inserted successfully.",
        "student": new_student.__dict__  # Serialize SQLAlchemy object for response
    }

@app.get("/students/")
def get_students_details(db: Annotated[Session, Depends(database.get_db)]):
    #all_students = db.query(base_model.StudentTable).all()
    try:
        all_students = db.query(base_model.StudentTable).filter(base_model.StudentTable.etlExecuted==0).all()
    except Exception as e:
       print(f"error during api call is {e}")
       raise HTTPException(status_code=500, detail=f"An error occurred while fetching students: {str(e)}")
    if not all_students:
        raise HTTPException(status_code=404, detail="No student records found")
    return [student.__dict__ for student in all_students]  # Ensuring correct serialization

def parse_ids(stdid: Union[int, str]) -> List[int]:
    """
    Parses the incoming `stdid` (either int or comma-separated string) into a list of IDs.
    """
    if isinstance(stdid, int):
        return [stdid]  # Wrap single ID in a list
    if isinstance(stdid, str):
        return [int(i) for i in stdid.split(",")]  # Split and convert comma-separated IDs
    else:
        return []

@app.put("/student/{stdid}/")
def update_etlExecuted(db: Annotated[Session, Depends(database.get_db)], stdid: Union[int, str]):
    try:
        # Parse input stdid into a list of IDs
        id_list = parse_ids(stdid)
        # Query the database for student records with matching IDs
        students = db.query(base_model.StudentTable).filter(base_model.StudentTable.id.in_(id_list)).all()
        if not students:
            raise HTTPException(status_code=404, detail="No student records found")
        # Update ETL status and timestamp for each student
        for student in students:
            student.etlExecuted = 1
            student.insertDate = datetime.strptime(datetime.now().isoformat(),"%Y-%m-%dT%H:%M:%S.%f")  # Use UTC for consistency
        # Commit changes to the database
        db.commit()
        return {"message": f"{len(students)} student record(s) updated successfully"}

    except Exception as e:
        db.rollback()  # Rollback the transaction in case of errors
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")
    

if __name__=='__main__':
    import uvicorn
    #fetching host and port nme based on the url, which is coming from the configs.
    #Url will change based on the data base and based on the environment.
    parsed_url = urlparse(url)
    host = parsed_url.hostname  # Get the host (e.g., '127.0.0.1')
    port = parsed_url.port 
    uvicorn.run(app,host=host,port=port)
    #uvicorn.run(app,host='127.0.0.1',port=8002)

