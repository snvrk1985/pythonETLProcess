from pydantic import BaseModel,ConfigDict
from datetime import datetime
import configs
from  database import dbname 
dbname="source"
dbname = configs.get_database_name()

class StudentTable(BaseModel):
    id:int
    fname:str
    lname:str
    contact:int
    age:int
    if dbname=="source":
        etlExecuted:bool
    insertDate:datetime
    model_config = ConfigDict(arbitrary_types_allowed=True)

class StudentResponse(BaseModel):
    id: int
    fname: str
    lname: str
    age: int
    contact: int
    insertDate: datetime
    class Config:
        model_validate = True

'''class StudentFee(BaseModel):
    id:int
    stdid:int
    fee:int
class StudentClass(BaseModel):
    id:int
    stdid:int
    stdClass:int'''

