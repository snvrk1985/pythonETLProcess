from datetime import datetime
from fastapi import HTTPException
import requests,configs,os,sys
from targetEtlCalls import execute_migration
from threading import Lock


db_lock = Lock()

url=configs.urlConfig("source")
#stdIds=[]
migratedStudents=[]
def insertStudents():
    # Generate a consistent timestamp for all records
    timestamp = datetime.now().isoformat()

    # Data to insert
    data = [
        {
            "contact": 9441345208,
            "id": 5,
            "lname": "S.",
            "age": 40,
            "fname": "Valli",
            "etlExecuted": 0,
            "insertDate": timestamp
        }
    ]
    # Post each record to the API
    for student in data:
        with db_lock: 
            try:
                response = requests.post(f"{url}/students/", json=student)
                print(f"Response for Student ID {student['id']}: {response.status_code}, {response.text}")
            except Exception as e:
                print(f"error occured due to {e}")
            finally:
                # Create a DataFrame and save to CSV
                print(response.json)
#insertStudents()

#stdDetails = []
def getAllStudents():
    stdDetails = []
    url=configs.urlConfig("source")
    response = None  # Initialize the variable
    timestamp = datetime.now().isoformat()
    try:
        response = requests.get(f"{url}/students/")
    except Exception as e:
        print(f"Error in calling API is: {e}")
        response = None  # Handle the exception gracefully by setting `response` to None
    finally:
        #print(f"fetch resoponce from source get students {response.json()}")
        if response and response.status_code == 200:  # Check if the response is valid
            required_columns = [
                                {"id": student["id"], 
                                 "fname": student["fname"],
                                 "lname": student["lname"], 
                                 "age": student["age"],
                                 "contact": student["contact"],
                                 "insertDate":  timestamp,
                                 } 
                                 for student in response.json()]
            stdDetails.extend(required_columns)
        else:
            print("Failed to fetch students or no response returned")
            return []  # Return an empty list if the API call fails

    #here executing start migrating data from source to target if there is updated records
    if len(stdDetails):
        try:
            url=configs.urlConfig("target")
            configs.DatabaseName("target")
            execute_migration(True,stdDetails,url)
        except Exception as e:
            print(f"error is {e}")
            raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

