import sqlite3

# Connect to SQLite database
connection = sqlite3.connect('target.db')
cursor = connection.cursor()

try:
    # Step 1: Create a new table without the unwanted column
    cursor.execute("""
        CREATE TABLE student_table_new AS
        SELECT id, fname, lname, age, contact, insertDate
        FROM student_table;
    """)

    # Step 2: Drop the original table
    cursor.execute("DROP TABLE student_table;")

    # Step 3: Rename the new table to the original name
    cursor.execute("ALTER TABLE student_table_new RENAME TO student_table;")

    print("Column 'etlExecuted' removed successfully.")
except sqlite3.OperationalError as e:
    print(f"Error: {e}")
finally:
    # Commit changes and close the connection
    connection.commit()
    connection.close()
