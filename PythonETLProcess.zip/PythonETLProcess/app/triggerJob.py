import schedule,time
from sourceEtlCalls import getAllStudents

def my_function():
    #global stdDetails
    getAllStudents()
# Schedule the function to run every 2 minutes
schedule.every(2).minutes.do(my_function)

while True:
    schedule.run_pending()
    time.sleep(1)