import boto3


'''session = boto3.Session(
    aws_access_key_id="AKIA3W7FYB2M67ZT6VYR",
    aws_secret_access_key="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",
)'''

session = boto3.Session(
    aws_access_key_id="AKIAVVZOOKESXYFM34VU",
    aws_secret_access_key="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",
)

s3_client = session.client("s3")  

# Define bucket name and file details
bucket_name = "pythonetlpipe"

def copyToS3(file_name):
    # ✅ Upload file
    s3_client.upload_file(Filename=file_name, Bucket=bucket_name, Key=file_name)
    #print(f"✅ {file_name} uploaded successfully to {bucket_name}/{file_name}")

    # ✅ Check if file exists in S3
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=file_name)

    if "Contents" in response:
        #print(f"✅ File '{file_name}' successfully uploaded and found in S3!")
        return  True
    else:
       # print(f"❌ File '{file_name}' not found in S3.")
        return False

#below code to store csv without storing in local, directly to s3